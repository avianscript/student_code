package EcommerceMachine;

import java.io.FileNotFoundException;

public class Main {


    public static void main(String[] args) throws FileNotFoundException {
        Menus menu = new Menus();
        menu.mainMenuRun();
    }
}
